#ifndef TAC_UTILS_H
#define TAC_UTILS_H

#include <bits/stdc++.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

inline int temp_counter = 0;
inline int label_counter = 0;

inline ofstream tacout("tempTacOutput");

class tac_type {
    public:
    string code;         // Generated code lines
    vector<tac_type*> truelist;             // For boolean expressions
    vector<tac_type*> falselist;
    vector<tac_type*> nextlist;
    tac_type* next;

    tac_type(const string& line){
        code = line;
    }
};


inline string new_temp() {
    return "t" + to_string(temp_counter++);
}

inline string new_label() {
    return "L" + to_string(label_counter++);
}

inline tac_type* emit_tac(const string& line) {
    return new tac_type(line);
}

inline void print_tac(tac_type* curr) {
    while(curr!=NULL) {
        tacout << curr->code << endl;
        curr = curr->next;
    }
}

#endif // TAC_UTILS_H
