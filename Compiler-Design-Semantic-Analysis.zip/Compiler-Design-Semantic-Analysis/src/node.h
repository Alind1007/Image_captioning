#include <bits/stdc++.h>
#include "tac_utils.h"

using namespace std;

extern void sem_error(string);
extern set<string> disallowedNames;
extern map<pair<string, string>, string> expResult;

inline ofstream symout("tempSymtabOutput");


class Node {
public:
    string name = "";
    string type = "void";
    string temp_name;
    string place;
    int pointerCnt = 0;
    int arrayCnt = 0;
    bool isVariable = false;
    bool isFunction = false;
    bool isStruct = false;
    bool isStructDefinition = false;
    bool isStatic = false;
    vector<pair<string, Node*>> parameterList;
    tac_type* tac;
    tac_type* tac_end;
    string label;
    // map<string, string> variableList;
    // map<string, Node*> table;
    
    Node() = default;
    bool valid(){
        // if(!isFunction){
        if(disallowedNames.find(name) != disallowedNames.end()){
            sem_error("at " + name + ": cannot use reserved keyword as variable name");
            return false;
        }
        if(pointerCnt > 1){
            sem_error("at " + name + ": cannot support multi-level pointers");
            return false;
        }
        if(arrayCnt > 1){
            sem_error("at "+ name + ": cannot support multi-dimensional arrays");
            return false;
        }
        if(pointerCnt && arrayCnt){
            sem_error("at "+ name + ": cannot support both pointer and array at the same time");
            return false;
        }
        if(arrayCnt && (type != "int" && type != "char")){
            sem_error("at "+ name + ": only int and char can be array type");
            return false;
        }
        return true;
    }


    bool compareParameterList(Node* other) {
        if (parameterList.size() != other->parameterList.size()) {
            return false;
        }
        for (size_t i = 0; i < parameterList.size(); ++i) {
            if (parameterList[i].second->pointerCnt+parameterList[i].second->arrayCnt != other->parameterList[i].second->pointerCnt + other->parameterList[i].second->arrayCnt ||
                parameterList[i].second->isVariable != other->parameterList[i].second->isVariable ||
                parameterList[i].second->isFunction != other->parameterList[i].second->isFunction ||
                parameterList[i].second->isStruct != other->parameterList[i].second->isStruct ||
                parameterList[i].second->isStructDefinition != other->parameterList[i].second->isStructDefinition
            ) {
                return false;
            }
            else if(expResult.find({parameterList[i].second->type, other->parameterList[i].second->type}) != expResult.end()){
                return true;
            }
            else if(parameterList[i].second->type != other->parameterList[i].second->type){
                sem_error("at " + name + ": function parameter type mismatch: " + parameterList[i].second->type + " and " + other->parameterList[i].second->type);
                return false;
            }
        }
        return true;
    }

    bool convertibleToBool(){
        if(isFunction){
            sem_error("at " + name + ": cannot convert function name to bool (conditional expression)");
            return false;
        }
        if(isStruct){
            sem_error("at " + name + ": cannot convert struct variable to bool (conditional expression)");
            return false;
        }
        if((pointerCnt || arrayCnt)){
            sem_error("at " + name + ": cannot convert pointer or array to bool (conditional expression)");
            return false;
        }
        if(isStructDefinition){
            sem_error("at " + name + ": cannot convert struct definition to bool (conditional expression)");
            return false;
        }
        if(type == "void"){
            sem_error("at " + name + ": cannot convert void to bool (conditional expression)");
            return false;
        }
        if(type == "int" || type == "float" || type == "char" || type == "bool"){
            return true;
        }
        return false;
    }
    

    void printAttributes(){
        // symout << "Node Attributes:" << endl;
        symout << "Name: " << name << endl;
        symout << "Type: " << type << endl;
        symout << "Pointer Count: " << pointerCnt << endl;
        symout << "Array Count: " << arrayCnt << endl;
        symout << "Is Variable: " << (isVariable ? "Yes" : "No") << endl;
        symout << "Is Function: " << (isFunction ? "Yes" : "No") << endl;
        symout << "Is Struct: " << (isStruct ? "Yes" : "No") << endl;
        symout << "Is StructDefinition: " << (isStructDefinition ? "Yes" : "No") << endl;
        symout << "Is Static: " << (isStatic ? "Yes" : "No") << endl;
        symout << "Parameter List:" << endl;
        symout << "[";
        for (size_t i = 0; i < parameterList.size(); ++i) {
            symout << "{" << parameterList[i].first << ", " << parameterList[i].second->type << "}";
            if (i != parameterList.size() - 1) {
            symout << ", ";
            }
        }
        symout << "]" << endl;
    }
};
    
class GlobalParameters {
    public:
    // bool isVariableDeclaration = false;
    bool isFunction = false;
    // bool isAssignment = false;
    bool isStatic = false;
    // bool inForLoop = false;
    string type = "void";
    bool isStruct = false;
    bool isStructDefinition = false;
    vector<pair<string, Node*>> parameterList;
    map<string, Node> table; // Symbol table for the current function scope
    GlobalParameters() = default;
    void reset() {
        // isVariableDeclaration = false;
        isFunction = false;
        // isAssignment = false;
        type = "void";
        parameterList.clear();
        table.clear();
    }
};