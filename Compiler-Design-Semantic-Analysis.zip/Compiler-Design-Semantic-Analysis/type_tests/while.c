int main() {
    int i = 1;

    while (i <= 5) {
        printf("Count: %d\n", i);
        i++;
    }

    return 0;
}
