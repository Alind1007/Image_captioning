struct Node{
    int data;
    int *ptr;
};

int main(){
    struct Node *node;
    int arr[10];
    arr[0] = 5;
    arr[1] = 10;
    char carr[arr[0]];
    carr[0] = 'A';
    carr[1] = 'B';
    int *ip = &(arr[0]);
    arr[1] = node->data;
    
    *ip = carr; // error same kind should be used
    arr[1] = node.data; // error only usable on pointers

    return 0;
}