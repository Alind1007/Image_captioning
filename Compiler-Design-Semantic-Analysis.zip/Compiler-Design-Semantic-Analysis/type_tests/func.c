void greet(char* name) {
    printf("Hello, %s!\n", name);
}

int main() {
    greet("Atish");

    return 0;
}
