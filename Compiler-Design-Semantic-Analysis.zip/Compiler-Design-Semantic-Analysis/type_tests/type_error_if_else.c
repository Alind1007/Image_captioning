struct Node{
    int data;
    int *ptr;
};

int main(){
    struct Node node;    
    int int_var = 5;
    float float_var = 3.14;
    char char_var = 'A';
    bool bool_var = true;

    if(int_var + float_var) { // Valid: int + float in condition
        int_var += 2;
    }
    else if(bool_var) { // Valid: bool in condition
        float_var *= 1; 
    }
    else if(char_var) { // Valid: char in condition
        char_var--; 
    }
    else {
        bool_var = !bool_var; 
    }

    if(node) { // Invalid: struct type used as a condition
        int_var++;
    }
    if(&char_var) { // Invalid: pointer used as a condition
        float_var += 1.0;
    }

    return 0;
}