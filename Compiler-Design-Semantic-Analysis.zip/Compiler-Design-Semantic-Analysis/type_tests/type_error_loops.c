struct Node{
    int data;
    int *ptr;
};

int main(){
    struct Node node;    
    int int_var = 5;
    float float_var = 3.14;
    char char_var = 'A';
    bool bool_var = true;

    for(int i = 10; i > 0; i--) { // Valid: int in for loop
        int_var += i; // Valid: int + int
    }
    for(float i = 0.0; i < 10; i += 1.0) { // Valid: float in for loop
        float_var *= i; // Valid: float * float
        for(int_var = 1; int_var < 10; int_var++) { // Valid: int in for loop
            char_var--; // Valid: char--
        }
    }
    while(int_var < 20) { // Valid: int in while loop
        int_var += 1; // Valid: int + int
    }
    while(float_var > 0.0) { // Valid: float in while loop
        float_var -= 1.0; // Valid: float - float
        for(int i = 10; i > 0; i--) { // Valid: int in for loop
            int_var += i; // Valid: int + int
        }
    }

    for(bool_var = true; node; bool_var = false) { // invalid: struct in for condition
        int_var += 1; 
    }

    while(&int_var){
        int_var += 1; // Valid: int + int
    }


    return 0;
}