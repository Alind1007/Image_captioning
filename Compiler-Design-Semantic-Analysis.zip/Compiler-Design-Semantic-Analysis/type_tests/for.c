int main() {
    for (int i = 1; i <= 5; i++) {
        printf("Iteration %d\n", i);
    }

    return 0;
}
