int main(){
    int a = 5, b = 10;
    bool flag = a<b;
    a = a+flag*(b-a);
    printf("%d\n", a);
    return 0;
}
