int global_var = 213;

int* fun(int a, int b){
    int c[];
    int d = 2;
    return c;
}

int main(){
    int *b = fun(1, 2);
    return 0;
}