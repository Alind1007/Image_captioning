struct Node{
    int data;
    int *ptr;
};

int main(){
    struct Node node;    
    int int_var = 5;
    float float_var = 3.14;
    char char_var = 'A';
    bool bool_var = true;

    int_var += 2; // Valid
    float_var *= 1; // Valid
    char_var--; // Valid
    bool_var = !bool_var; // Valid
    bool flag = int_var||float_var; //valid

    int a = 5, b = 10; // valid
    bool flag = a < b; // valid
    a = a + flag * (b - a); // valid
    printf("%d\n", a); // valid
    
    // int ans = node + int_var; // Invalid: struct + int
    // float val = int_var % float_var; // Invalid: float shouldn't be used with %
    bool_var = int_var ^ float_var; // Invalid: float shouldn't be used with bitwise operators
    // int shifted = int_var << float_var; // Invalid: float shouldn't be used with <<
    return 0;
}