int fact(int n){
    if(n == 0 || n == 1){
        return 1;
    }
    return n * fact(n-1);
}

struct Data
{
    int x, y;
    char c;
};

int main(){
    int a = 2, b = 2;
    for(int i=0;i<2;i+=1){
        i+=1;
    }
    int c = (1 == 2) ? 3 : 4;
    struct Data d1;
    d1.x = 5;
    d1.y = 10;
    int ans1 = fact(d1.c);
    int ans2 = fact(d1.y);
    scanf("Factorial of %d is %d\n", d1.c, ans1);
    printf("Factorial of %d is %d\n", d1.c, ans1);
    return 0;
}