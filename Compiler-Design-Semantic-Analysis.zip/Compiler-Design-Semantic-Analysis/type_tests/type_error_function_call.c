

char fun1(){
    int a = 5;
    return &a;
}
//wrong return statement

int fun(int a, char* c){
    return a + *c;
}

int fact(int n){
    if(n == 0 || n == 1){
        return 1;
    }
    return n * fact(n-1);
}
//supports recursion

int main(){
    char c = 'D';
    char *cp = &c;
    int val = fun(5, cp);    
    int result = fact(val);
    return 0;
}


