struct Node{
    int a;
    int *b;
    char c;
};

int main(){
    struct Node n;
    int a;
    return 0;
}