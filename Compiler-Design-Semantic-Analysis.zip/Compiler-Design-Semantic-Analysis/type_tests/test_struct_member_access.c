struct Node{
    int a, b, c;
};

int main(){
    // struct Node node;
    // node.a = 1;
    // node.b = 2;
    // node.c = 3;
    // struct Node* nodePtr;
    // nodePtr.a = 4;
    // nodePtr->b = 5;
    for(int i=0;i<5;i++){
        int a = 0;
        for(int j=0;j<5;j++){
            int a = 99;
        }
    }
    return 0;
}


int fun(int a, char c){

}

