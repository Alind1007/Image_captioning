int main() {
    int count = 1;

start:  // This is the label
    printf("Count is %d\n", count);
    count++;

    if (count <= 5)
        goto start;  // Jumps back to the label

    printf("Loop ended using goto.\n");

    return 0;
}
