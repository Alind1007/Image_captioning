int main(){
    int a = 5, b = 6;
    int c = a * b;
    int d = c + b;
    int x, y;
    int z = x * y;
    z = x + y;
    z = x<<y;
}