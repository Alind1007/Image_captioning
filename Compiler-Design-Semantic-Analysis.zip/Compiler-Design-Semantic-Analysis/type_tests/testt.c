struct Node{
    int a;
};

struct Node* fun(int a, int b){
    struct Node c;
    return &c;
}

// int main(){
//     int b, c;
//     float aa, bb, cc;
//     bool x , y, z;
//     char c1, c2, c3;
//     // int k = (((c1|x)&&a) + b)<<1;
//     int a = b +(b<10);
//     return 0;
// }

int main(){
    struct Node *n = fun(1, 2);
    while(n->a){
        int a = 0, b = 2.5;
        a = b + n->a;
        return 0;
    }
}


// struct Node{
//     int data;
// };

// struct Node aba;

// int main(){
//     // aba.data = 5;
//     int ptr;
//     ptr.data = 10;
//     aba.dat=21;
//     int a;
//     while(a--){
//         int a;
//         int b = a;
//     }
    
// }
