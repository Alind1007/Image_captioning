struct Node{
    int a;
};

int main(){
    int a;
    char c;
    struct Node n;
    switch (a+c){
    case 1:
        break;
    case n: // Error: struct Node cannot be used in switch case
        break;
    default:
        break;
    }

    switch (n){
    case 0:
        break;
    default:
        break;
    }
    return 0;
}