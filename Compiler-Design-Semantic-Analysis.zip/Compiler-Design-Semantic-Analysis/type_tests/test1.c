float hari = 0.22f;
char hello = 'h';
int a = 15;
int b[];

void fun(int a, int b, int c){
    return;
}

int main(){
    int *pointerVariable;
    int arr[], p[];
label:
    for(int i, j, k=0;i<n;i++){
        int a = 12+i;
    }
    goto label;
}
