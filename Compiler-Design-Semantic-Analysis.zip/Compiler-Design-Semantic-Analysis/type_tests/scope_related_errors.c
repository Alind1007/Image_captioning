
struct Node{
    int a;
};

struct Node n1;

int funName(){
    return 0;
}

int main(){
    struct Node{
        int n;
    };
    struct Node n;
    n.a = 5; //gives error
    n.n = 5; //correct usage
    n1.a = 5; // correct usage
    n1.n = 5; //wrong usage
    
    funName();//doesnt give error
    int funName;
    funName(); //gives error
    int a;
    char a; //redeclaration of a

    for(int a = 0; a < 10; a++){
        int b = 0;
        while(b < 5){
            int c = 0;
            if(c == 0){
                int d = 0;
                d++;
            }
            b++;
        }
    }
    return 0;
}