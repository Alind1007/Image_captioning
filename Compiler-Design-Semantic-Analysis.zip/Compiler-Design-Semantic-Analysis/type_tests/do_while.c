int main() {
    int i = 1;

    do {
        printf("i is %d\n", i);
        i++;
    } while (!(i > 5));  // Run until i > 5

    return 0;
}
