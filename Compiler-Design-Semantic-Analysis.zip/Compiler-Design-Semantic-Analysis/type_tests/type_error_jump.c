int main(){
    int a = 5, b = 10;
    bool flag = a < b;
label:
    a++;
    if(flag){
        goto label;
    }
    break; // error
    continue; //error
    for(int i = 0; i < 10; i++){
        if(i == 5){
            break;
        }
        else{
            continue;
        }
    }
    return 0;
}