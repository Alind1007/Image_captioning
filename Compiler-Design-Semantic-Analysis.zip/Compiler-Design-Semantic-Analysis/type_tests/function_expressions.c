struct Node{
    int arr[];
};

struct Node* fun(int a, int b){
    struct Node* c;
    return c;
}

int main(){
    int k = fun(1, 2)->arr[0];
    return 0; 
}
