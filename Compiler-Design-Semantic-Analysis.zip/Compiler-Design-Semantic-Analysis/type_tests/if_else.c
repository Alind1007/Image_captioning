int main() {
    int num = 10;

    if (num > 0)
        printf("Number is positive\n");
    else
        printf("Number is zero or negative\n");

    return 0;
}
