BIN_DIR="./bin"
TEST_DIR="./type_tests"

rm -rf type_test_output
mkdir type_test_output

for test_case in "$TEST_DIR"/*.c; do
    echo "Running test case: $test_case"
    "$BIN_DIR"/parser < "$test_case" > "type_test_output/$(basename "$test_case" .c)_parsed.txt"
done
