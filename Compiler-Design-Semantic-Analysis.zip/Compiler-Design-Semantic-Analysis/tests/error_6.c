int x = 1;
struct Node{
    int ***a[10][];
    struct Data &next;
    int 21f;
};


int fun(int *a, int *b[], char c){
    struct Node *n;
    n->next = NULL;
    return 0;
    int *m = (int *)malloc(sizeof(int));
    while(n--) n++;
}

static int main(){
    unsigned  int char a = 10;
}