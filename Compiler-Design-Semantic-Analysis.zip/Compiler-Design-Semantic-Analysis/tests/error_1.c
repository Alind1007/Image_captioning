int main() {
    printf("Hello, World!")  // ❌ Missing semicolon
    return 0;
}
