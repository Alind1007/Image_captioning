int main() { 
    int arr[3] {1, 2, 3};  // ❌ Should use `=` for initialization: `= {1, 2, 3};`
    return 0;
}