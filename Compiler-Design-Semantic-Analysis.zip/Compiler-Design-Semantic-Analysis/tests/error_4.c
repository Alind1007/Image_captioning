int main() {
    for int i = 0; i < 5; i++) {  // ❌ `for` syntax should have parentheses
        printf("%d\n", i);
    }
    return 0;
}
