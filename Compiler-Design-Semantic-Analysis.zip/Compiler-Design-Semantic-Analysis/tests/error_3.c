void sayHello();  // ❌ Missing function body braces `{}` 
    printf("Hello\n");
int main() {
    sayHello();
    return 0;
}
