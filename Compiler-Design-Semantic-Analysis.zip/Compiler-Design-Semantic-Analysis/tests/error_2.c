int main() {
    int x = 5;
    if (x > 3)  
        printf("X is greater than 3\n");  
    }// ❌ Extra closing brace that does not match any opening brace
    return 0;
}