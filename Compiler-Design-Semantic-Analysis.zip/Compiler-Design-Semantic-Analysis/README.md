# C-like Language Parser

## 📌 Introduction
A **Semantic-Analyzer/Parser** and **Intermediate Code Generator** is the third phase of a compiler. A **Semantic Analyzer** checks for logical consistency and type correctness, a **Parser** ensures syntactic correctness, and an **Intermediate Code Generator** translates the code into a lower-level intermediate representation like **Three Address Code** (3AC). This project includes a **C/C++ lexer** built using **Lex (Flex)**, which tokenizes C++ source code based on predefined patterns, and a **C-like parser** that performs syntax and semantic analysis on these tokens and also generates the symbol table and Intermediate code in Three Address Code format. 

## 🔧 Dependencies
To use this parser, ensure you have the following installed:
- **Lex (or Flex)** – A tool for generating lexical analyzers.
- **Bison** – A tool for generating syntax analyzers.
- **G++** – GNU Compiler Collection to compile the generated `lex.yy.cpp` && `grammar.tab.cc` file.
- **Make** – To simplify the build process.

### 📥 Installation
#### Install Flex/Bison:
- **Linux (Ubuntu/Debian):**
  ```bash
  sudo apt update && sudo apt install flex
  sudo apt update && sudo apt install bison
  ```
- **MacOS (Using Homebrew):**
  ```bash
  brew install flex
  brew install bison
  ```
- **Windows:**
  - Install **Cygwin** or **MinGW** and include `flex` and `bison` in the package selection.
  - Alternatively, use **WSL** (Windows Subsystem for Linux) and install `flex` and `bison` using the Ubuntu instructions.

## 🚀 Build & Run Instructions

### 1️⃣ Compile the files in src
To generate the lexer and compile it:
```bash
make parser
```
This runs `lex` and `bison` to generate `lex.yy.cc` `grammar.tab.hh` and `grammar.tab.cc` , then compiles them into an executable `parser` inside the `bin/` directory.

### 2️⃣ Run the Parser
Ensure the `run2.sh` script has execution permissions:
```bash
chmod +x run2.sh
```
Place the `.c` type test files in the type test directory and then execute the script:
```bash
./run2.sh
```
This will run parser on the input files and produce the output after parsing(syntax errors/token, tokentype table) into `type_test_output` directory.

### 3️⃣ Clean Up Generated Files
To remove the compiled and generated files:
```bash
make clean
```
This deletes the `bin/parser` executable, `.cpp` files generated and `type_test_output` directory.

## 📜 File Structure
```
├── src/
│   ├── grammar.y       # Grammar definition file (yacc)
│   ├── lex.l           # Lexer definition file (lex)
│   ├── tac_utils.h     # Contains Data structure used for generation of tac
│   ├── node.h          # Contains Data structure used for generation of symbol table
├── type_tests/         # type test files directory
├── Makefile            # Makefile for build automation
├── Readme              # Description of the repository
├── run.sh              # Shell script to run the lexer
```



